package com.sanju.systemx.sfx

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.ui.Pal
import java.lang.ref.WeakReference

/**
 * UI sound effects of SanjuSystemX. File names refer to res/raw/<file>.wav; they are looked up by name at runtime,
 * so a missing file simply means that one sound stays silent (no crash).
 * priority: higher wins; a lower-priority sound is dropped while a higher one is still playing.
 */
enum class Sfx(
    val file: String, val cooldownMs: Long, val priority: Int, val durationMs: Long,
    val haptic: Boolean = false, val reject: Boolean = false
) {
    CLICK("sfx_click", 60, 1, 40),
    TOGGLE_ON("sfx_toggle_on", 90, 1, 160),
    TOGGLE_OFF("sfx_toggle_off", 90, 1, 160),
    SUCCESS("sfx_success", 250, 2, 350),
    SPACE_OPEN("sfx_space_open", 500, 3, 420),
    GAME_DETECTED("sfx_game_detected", 800, 3, 260, haptic = true),
    OPTIMIZE_DONE("sfx_optimize_done", 400, 3, 480, haptic = true),
    GAME_LAUNCH("sfx_game_launch", 800, 4, 280),
    BOOST_ON("sfx_boost_on", 600, 4, 410, haptic = true),
    WARNING("sfx_warning", 400, 5, 310, haptic = true, reject = true)
}

/** One instance per MainActivity. Uses SoundPool: no audio focus is requested and no system volume is touched. */
class SfxPlayer(context: Context, private val prefs: Prefs) {
    private val appCtx = context.applicationContext
    private val lock = Any()
    private var pool: SoundPool? = null
    private val ids = HashMap<Sfx, Int>()
    private val loaded = HashSet<Int>()
    private val lastPlayed = HashMap<Sfx, Long>()
    private var hapticView: WeakReference<View>? = null
    private var busyUntil = 0L
    private var busyPriority = 0
    private var lastStream = 0
    private var pending: Sfx? = null
    private var pendingAt = 0L
    private var released = false

    init {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val p = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build()
            p.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0) {
                    var again: Sfx? = null
                    synchronized(lock) {
                        loaded.add(sampleId)
                        val pd = pending
                        if (pd != null && ids[pd] == sampleId && SystemClock.uptimeMillis() - pendingAt < 1500) again = pd
                        if (again != null) pending = null
                    }
                    again?.let { play(it) }
                }
            }
            pool = p
            for (s in Sfx.values()) {
                val res = try { appCtx.resources.getIdentifier(s.file, "raw", appCtx.packageName) } catch (e: Throwable) { 0 }
                if (res == 0) continue
                val id = try { p.load(appCtx, res, 1) } catch (e: Throwable) { 0 }
                if (id != 0) ids[s] = id
            }
        } catch (e: Throwable) {
            pool = null
        }
    }

    /** Haptics need a view; only a weak reference is kept. */
    fun attachHaptics(v: View) { hapticView = WeakReference(v) }

    fun play(s: Sfx) {
        if (released) return
        val now = SystemClock.uptimeMillis()
        synchronized(lock) {
            val last = lastPlayed[s] ?: 0L
            if (now - last < s.cooldownMs) return
        }
        if (Pal.haptic && s.haptic) buzz(s)
        if (!prefs.getB("sfx_on", true)) return
        val p = pool ?: return
        val id = ids[s] ?: return
        val vol = prefs.getF("sfx_vol", 0.6f).coerceIn(0f, 1f)
        if (vol <= 0f) return
        synchronized(lock) {
            if (id !in loaded) { pending = s; pendingAt = now; return }
            if (now < busyUntil) {
                if (s.priority < busyPriority) return
                try { p.stop(lastStream) } catch (e: Throwable) { }
            }
            val stream = try { p.play(id, vol, vol, s.priority, 0, 1f) } catch (e: Throwable) { 0 }
            if (stream != 0) {
                lastStream = stream
                lastPlayed[s] = now
                busyUntil = now + s.durationMs
                busyPriority = s.priority
            }
        }
    }

    /** Follows the system "touch feedback" setting; it cannot force a vibration. */
    private fun buzz(s: Sfx) {
        val v = hapticView?.get() ?: return
        try {
            val c = if (Build.VERSION.SDK_INT >= 30) {
                if (s.reject) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.CONFIRM
            } else HapticFeedbackConstants.LONG_PRESS
            v.performHapticFeedback(c)
        } catch (e: Throwable) { }
    }

    fun release() {
        if (released) return
        released = true
        synchronized(lock) {
            try { pool?.release() } catch (e: Throwable) { }
            pool = null
            ids.clear(); loaded.clear(); pending = null
        }
        hapticView = null
    }
}

/** Global access point (same style as Pal). Holds the player only while a MainActivity is alive. */
object SfxHub {
    @Volatile private var player: SfxPlayer? = null
    fun bind(p: SfxPlayer) { player = p }
    fun unbind(p: SfxPlayer) { if (player === p) player = null }
    fun play(s: Sfx) { player?.play(s) }
}
